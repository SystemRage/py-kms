#!/usr/bin/env python

import uuid

key = uuid.uuid4().hex
print key[:16]
