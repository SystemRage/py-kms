#!/usr/bin/env python3

import uuid

key = uuid.uuid4().hex
print(key[:16]) #*2to3*
